<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


// Email configuration
$smtpHost = 'smtp.gmail.com';
$smtpUser = 'studentcouncilymca2k24@gmail.com'; // Replace with your Gmail address
$smtpPass = 'poex rskx cyyr urxg'; // Replace with your Gmail password
$smtpPort = 587;
$smtpSecure = 'tls';

// Define recipients and their respective email bodies
$recipients = [
    'lakhneetvlogsofficial@gmail.com' => 'I hope this message finds you well. My name is Aditi and I am reaching out on behalf of
J.C.Bose University (YMCA), to extend a heartfelt invitation to our upcoming university
fest.
With you at every frame, authenticity and creativity blend seamlessly into your unique
narrative. You have a gift for creating content that not only entertains but also leaves a
lasting impression on your audience.
What will the fest offer?
● Fest will showcase a lively and energetic atmosphere with a crowd eager to see your
magic.
● At Fest, you can seize the opportunity to expand your network, increase your fan
base, and have a blast doing it.
● It will generate the chance to create compelling content for your channel and extend
your reach to new fans.
● Plus, you’ll be featured in all our promotions—because who better to turn heads with
your trendsetting fashion sense, effortlessly combining classic elegance with
contemporary flair?
Please let us know if you would be interested in the fest happening from 16th to 18th
September at J.C.Bose University (YMCA), Faridabad. We look forward to the possibility
of welcoming you and creating an enamoring experience.
Warm regards,
Name: Aditi
Contact no.: 87003 08790
','anuvjain.work@gmail.com'=>'I hope this message finds you well. My name is Aditi and I am reaching out on behalf of
J.C.Bose University (YMCA), to extend a heartfelt invitation to our upcoming university
fest.
With you at the forefront of the stage, each note becomes a heartfelt expression of emotion
and artistry. Your melodies are like echoes in the soul, resonating with raw emotion and
authenticity. Your voice is a mesmerizing blend of passion and precision, captivating
audiences with each note.
What will the fest offer?
● Fest will showcase a lively and energetic atmosphere with a crowd eager to see your
magic.
● It will be an opportunity to expand your network, increase your fan base, and have a
blast doing it.
● Plus, you’ll be featured in all our promotions—because who better to turn heads with
music that speaks to the soul and moves the crowd?
Your songs are breathtaking which leaves us all in awe, and we want more! Please let us
know if you would be interested in the fest happening from 16th to 18th September at
J.C.Bose University (YMCA), Faridabad. We look forward to the possibility of welcoming
you and creating an electrifying experience.
Warm regards,
Name: Aditi
Contact no.: 87003 08790','workforcarry@gmail.com'=>'I hope this message finds you well. My name is Aditi and I am reaching out on behalf of
J.C.Bose University (YMCA), to extend a heartfelt invitation to our upcoming university
fest.
With you at the helm of roast videos, no one is safe from your sharp wit and fearless
commentary. Your roasts are a masterclass in wit and humor, turning situations into hilarious
anecdotes. Your roast videos turn heads and spark laughter, showcasing your unique ability
to find humor.
What will the fest offer?
● Fest will showcase a lively and energetic atmosphere with a crowd eager to see your
magic.
● At Fest, you can seize the opportunity to expand your network, increase your fan
base, and have a blast doing it.
● It will generate the chance to create compelling content and extend your reach to
new fans.
● Plus, you’ll be featured in all our promotions—because who better at the art of
roasting with razor-sharp precision?
Please let us know if you would be interested in the fest happening from 16th to 18th
September at J.C.Bose University (YMCA), Faridabad. We look forward to the possibility
of welcoming you and creating an electrifying experience.
Warm regards,
Name: Aditi
Contact no.: 87003 08790','autojournalindia@gmail.com'=>'I hope this message finds you well. My name is Aditi and I am reaching out on behalf of
J.C.Bose University (YMCA), to extend a heartfelt invitation to our upcoming university
fest.
With you at the wheel, every video is a wild and adventurous ride. Turning every review clip
into a spectacularly written story with keen details is a talent that deserves applause. We
have been avid followers of your YouTube channel and Instagram page and truly admire
your passion and expertise. Your amazing collection will be a glee to watch in the fest.
What will the fest offer?
● Fest will showcase a lively and energetic atmosphere with a crowd eager to see your
magic.
● At Fest, you can seize the opportunity to expand your network, increase your fan
base, and have a blast doing it.
● It will generate the chance to create compelling content and extend your reach to
new fans.
● Plus, you’ll be featured in all our promotions—because who better to turn heads and
engines than you?
Your passion for cars is an adventure that leaves us all in awe, and we want more! Please
let us know if you would be interested in the fest happening from 16th to 18th September at
J.C.Bose University (YMCA), Faridabad. We look forward to the possibility of welcoming
you and creating an electrifying experience.
Warm regards,
Name: Aditi
Contact no.: 87003 08790','wearedesible@gmail.com'=>'I hope this message finds you well. My name is Aditi and I am reaching out on behalf of
J.C.Bose University (YMCA), to extend a heartfelt invitation to our upcoming university
fest.
With you orchestrating the beats, each member harmonizes seamlessly, creating a fusion of
sound that mesmerizes. Being the first crew from India to represent the country at GBB is a
great achievement. Your melodies are like echoes in the soul, resonating with raw emotion
and authenticity.
What will the fest offer?
● Fest will showcase a lively and energetic atmosphere with a crowd eager to see your
magic.
● It will be an opportunity to expand your network, increase your fan base, and have a
blast doing it.
● Plus, you’ll be featured in all our promotions—because who better to turn heads with
music that speaks to the soul and moves the crowd?
Your trail of melodies has been ruling along the charts, and we are hooked! Please let us
know if you would be interested in the fest happening from 16th to 18th September at
J.C.Bose University (YMCA), Faridabad. We look forward to the possibility of welcoming
you and creating an electrifying experience.
Warm regards,
Name: Aditi
Contact no.: 87003 08790
','workforsangeetkir@gmail.com'=>'I hope this message finds you well. My name is Aditi and I am reaching out on behalf of
J.C.Bose University (YMCA), to extend a heartfelt invitation to our upcoming university
fest.
With you at the forefront, each note becomes a heartfelt expression of emotion and artistry.
Your melodies are like echoes in the soul, resonating with raw emotion and authenticity.
What will the fest offer?
● Fest will showcase a lively and energetic atmosphere with a crowd eager to see your
magic.
● At Fest, you can seize the opportunity to expand your network, increase your fan
base, and have a blast doing it.
● Plus, you’ll be featured in all our promotions—because who better to turn heads with
music that speaks to the soul and moves the crowd?
Your songs are breathtaking which leaves us all in awe, and we want more! Please let us
know if you would be interested in the fest happening from 16th to 18th September at
J.C.Bose University (YMCA), Faridabad. We look forward to the possibility of welcoming
you and creating an electrifying experience.
Warm regards,
Name: Aditi
Contact no.: 87003 08790','bhatiamark795@gmail.com'=>'I hope this message finds you well. My name is Aditi and I am reaching out on behalf of
J.C.Bose University (YMCA), to extend a heartfelt invitation to our upcoming university
fest.
With you at the mic, the beats drop, and the crowd roars. Turning every word into a
spectacularly written story is a talent that deserves applause. Your songs TeTae ki Taant,
Drishti- Kon and many more are very relatable in a world of noise.
What will the fest offer?
● Fest will showcase a lively and energetic atmosphere with a crowd eager to see your
magic.
● Fest will be an opportunity to expand your network, increase your fan base, and
have a blast doing it.
● Plus, you’ll be featured in all our promotions—because who better to turn heads with
music that speaks to the soul and moves the crowd?
Your songs are breathtaking which leaves us all in awe, and we want more! Please let us
know if you would be interested in the fest happening from 16th to 18th September at
J.C.Bose University (YMCA), Faridabad. We look forward to the possibility of welcoming
you and creating an electrifying experience.
Warm regards,
Name: Aditi
Contact no.: 87003 08790',
    
    // Add more recipients and their messages as needed
];

$subject = 'Invitation';

$mail = new PHPMailer(true);

try {
    // SMTP configuration
    $mail->isSMTP();
    $mail->Host = $smtpHost;
    $mail->SMTPAuth = true;
    $mail->Username = $smtpUser;
    $mail->Password = $smtpPass;
    $mail->SMTPSecure = $smtpSecure;
    $mail->Port = $smtpPort;

    // Set the sender's email
    $mail->setFrom($smtpUser, 'Aditi');

    // Loop through recipients and send emails
    foreach ($recipients as $email => $body) {
        $mail->clearAddresses();
        $mail->addAddress($email);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
    }


echo "mail sent successfully from : ".$smtpUser." at ".date("Y-m-d H:i:s")." to"; 
  echo ("<pre>");
  print_r($recipients);
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
?>
